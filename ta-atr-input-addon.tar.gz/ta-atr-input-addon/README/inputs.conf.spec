[mywizard360-atr-modular-input://<name>]
*Gets data from ATR and indexes into Splunk
atr_ticket_type = <value>