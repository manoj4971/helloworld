define(['jquery'], function($) {

    /**
     * SecurityUtils module: A utility module for handling CSRF tokens, POST requests,
     * and future security features like request hashing and signing.
     *
     * @module SecurityUtils
     */

    /**
     * Function to get the CSRF token from cookies.
     *
     * @returns {string|null} The CSRF token or null if not found.
     */
    function getCSRFToken() {
        const cookies = document.cookie.split(';');
        let csrfToken = null;
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith('splunkweb_csrf_token_8000=')) {  // Adjust the port number if necessary
                csrfToken = cookie.substring('splunkweb_csrf_token_8000='.length, cookie.length);
                break;
            }
        }

        // Log the CSRF token for verification (REMOVE THIS IN PRODUCTION)
        if (csrfToken) {
            console.log("CSRF Token found:", csrfToken);
        } else {
            console.error("CSRF token not found.");
        }

        return csrfToken;
    }

    /**
     * Function to get the CSRF token dynamically based on the port.
     *
     * @returns {string|null} The CSRF token or null if not found.
     */
    function getDynamicCSRFToken() {
        const cookies = document.cookie.split(';');
        let csrfToken = null;

        // Dynamically get the current port from the URL
        const url = new URL(window.location.href);
        const port = url.port || "8000";  // Default to 8000 if no port is present in the URL

        const tokenPrefix = `splunkweb_csrf_token_${port}=`;

        // Iterate through cookies to find the CSRF token for the current port
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith(tokenPrefix)) {
                csrfToken = cookie.substring(tokenPrefix.length, cookie.length);
                break;
            }
        }

        // Log the CSRF token for verification (REMOVE THIS IN PRODUCTION)
        if (csrfToken) {
            console.log("Dynamic CSRF Token found.");
        } else {
            // CSRF token not found for port ${port}.
            console.error(`CSRF token not found .`);
        }

        return csrfToken;
    }

    /**
     * Function to perform a POST request with the CSRF token included.
     * This function can be extended to include features like request hashing or signing.
     *
     * @param {string} url - The URL to send the POST request to.
     * @param {object} data - The data to be sent in the POST request.
     * @returns {Promise} A promise that resolves if the request is successful, otherwise rejects.
     */
    async function postRequestWithSecurity(url, data) {
        // const csrfToken = getCSRFToken();
        const csrfToken = getDynamicCSRFToken();

        if (!csrfToken) {
            return Promise.reject("CSRF token not found. Cannot proceed with POST request.");
        }

        try {
            const response = await $.ajax({
                url: url,
                type: 'POST',
                data: data,
                beforeSend: function(xhr) {
                    // Set the CSRF token manually using setRequestHeader
                    xhr.setRequestHeader("X-Splunk-Form-Key", csrfToken);
                }
            });
            return response;
        } catch (error) {
            console.error("POST request failed:", error.statusText);
            throw error;
        }
    }

    /**
     * Function to perform a GET request with the CSRF token included and optional query parameters.
     *
     * @param {string} url - The base URL for the GET request.
     * @param {object} [params={}] - Optional parameters to be included as query parameters in the URL.
     * @returns {Promise} A promise that resolves if the request is successful, otherwise rejects.
     */
    async function getRequestWithSecurity(url, params = {}) {
        const csrfToken = getDynamicCSRFToken();

        if (!csrfToken) {
            return Promise.reject("CSRF token not found. Cannot proceed with GET request.");
        }

        // Construct the full URL with query parameters if params are provided
        let fullUrl = url;
        if (Object.keys(params).length > 0) {
            const queryString = new URLSearchParams(params).toString();
            fullUrl += `?${queryString}`;
        }

        try {
            const response = await $.ajax({
                url: fullUrl,
                type: 'GET',
                beforeSend: function(xhr) {
                    // Set the CSRF token manually using setRequestHeader
                    xhr.setRequestHeader("X-Splunk-Form-Key", csrfToken);
                }
            });
            return response;
        } catch (error) {
            console.error("GET request failed. An error occurred during the request.");
            throw new Error("Request failed. Please try again.");
        }
    }

    /**
     * Future method: A placeholder for creating a hash of the request data (e.g., HMAC).
     * This will be implemented later to add integrity checks.
     *
     * @param {object} data - The data to be hashed.
     * @returns {string} A hash string representing the request data.
     */
    function createDataHash(data) {
        // For future implementation of data hashing
        return ""; // Placeholder
    }

    /**
     * Future method: A placeholder for signing a request using public/private keys.
     * This will be implemented later for signing requests to ensure authenticity.
     *
     * @param {string} hashedData - The hashed data that needs to be signed.
     * @returns {string} The signed request.
     */
    function signRequest(hashedData) {
        // For future implementation of signing request using private keys
        return ""; // Placeholder
    }

    // Expose the functions for other scripts to use
    return {
        getCSRFToken: getCSRFToken,
        getDynamicCSRFToken: getDynamicCSRFToken,
        postRequestWithSecurity: postRequestWithSecurity,
        getRequestWithSecurity: getRequestWithSecurity,
        // Placeholder functions for future enhancements
        // createDataHash: createDataHash,
        // signRequest: signRequest
    };
});
