// Dynamically fetch the app name from the current URL
// get app name from url
var url = window.location.href.split("/");
let appName = url[url.indexOf("app") + 1];
let default_app = 'ta-atr-input-addon';
appName != default_app ? console.log("AppName:" + appName + " Default:" + default_app) : console.log("appname and default are same.");

require.config({
    paths: {
        'tasecurityUtils': '../../app/' + appName + '/js/ta_securityUtils',
    },
    scriptType: "module"
});


require([
    "tasecurityUtils",
], function(TaSecurityUtils) {
    // Log SecurityUtils to check if it's correctly loaded
    console.log("SecurityUtils loaded:", TaSecurityUtils);
    $('#modalconfig').hide();  // Close the modal initially.

    // Global flag to differentiate modal purpose
    let isNewStanza = false;


    // Fetch data with specific fields and populate the provided callback function
    async function fetchData(fields, callback, bringTable = "all") {
        console.log("Fetch data called");
        const url = Splunk.util.make_url("/custom/" + appName +"/table_controller/get_inputs_data");
        const params = { fields: fields.join(","), bringTable: bringTable };  // Convert fields array to comma-separated string

        try {
            const response = await TaSecurityUtils.getRequestWithSecurity(url, params);
            if (response.status === "Success") {
                console.log("Fetched response is:-");
                console.table(response.data);
                callback(response.data);  // Pass the data to the callback function for processing
                //This data is an array from backend.
            } else {
                alert(`Error: ${response.message}`);
                console.error("Failed to retrieve data:", response.message);
                return null;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return null;
        }
    }

    async function saveData(updateData) {
        const url = Splunk.util.make_url("/custom/" + appName +"/table_controller/update_stanza_data");
        console.log("Save data called.")
        try {
            await TaSecurityUtils.postRequestWithSecurity(url, updateData);
            console.log(`Data updated for ${updateData.name}`);
        } catch (error) {
            console.error("Failed to update data:", error);
            alert("Failed to update data. Please try again.");
            return false;  // Indicate failure for error handling
        }
        return true;  // Indicate success
    }



    // Populate the table with the fetched data
    function populateTable(data) {
        const tableBody = $("#table-body");
        tableBody.empty();  // Clear previous rows
        console.log("Populating main table-:")
        console.table(data);

        data.forEach(row => {
            const toggleStatus = row.status === "Disabled" ? "" : "checked";
            const rowHTML = `
                <tr>
                    <td><a href="javascript:void(0);" class="name-link" data-name="${row.Name}">${row.Name}</a></td>
                    <td>${row.atr_ticket_type}</td>
                    <td>${row.sourcetype}</td>
                    <td>${row.index}</td>
                    <td>
                        <label class="switch">
                            <input type="checkbox" class="status-toggle" data-name="${row.Name}" ${toggleStatus}>
                            <span class="slider"></span>
                        </label>
                    </td>
                </tr>`;
            tableBody.append(rowHTML);
        });
    }


    // Handle "New" button click
    $(document).off('click', '#new-stanza').on('click', '#new-stanza', function () {
        console.log("New button clicked. Opening modal for creating a new stanza.");

        isNewStanza = true; // Set flag for new stanza

        // Clear modal fields and make them writable with placeholders
        $("#stanza-name").val("").prop("readonly", false).attr("placeholder", "Enter stanza name");
        $("#ticket-type").val("").attr("placeholder", "Enter ticket type");
        $("#source-type").val("").attr("placeholder", "Enter source type");
        $("#interval").val("").attr("placeholder", "Enter interval (e.g., 300)");
        $("#index").val("").attr("placeholder", "Enter index name");

        // Show the modal
        $("#modalconfig").css("display", "block");
    });





    // Populate the modal fields with data
    function populateModalFields(data, name) {
        console.log("Populating modal fields for data");

        isNewStanza = false; // Set flag for editing existing stanza
        $('#stanza-name').val(name).prop("readonly", true); // Name is readonly for existing stanzas
        $('#ticket-type').val(data.atr_ticket_type);
        $('#source-type').val(data.sourcetype);
        $('#interval').val(data.interval);
        $('#index').val(data.index);

    }

    // Show the modal by fetching specific data and then populating it
    async function showModal(name) {
        // Fetch only the fields required for the modal for the specific stanza
        console.log("Show Modal called for :", name);
        await fetchData(["atr_ticket_type", "sourcetype", "interval", "index"], function(modalData) {
            if (modalData && modalData.length > 0) {
                populateModalFields(modalData[0], name);  // Populate the modal with the first (and only) item in the data
                $('#modalconfig').css('display', 'block');  // Show the modal
            } else {
                alert("Data for the selected name not found.");
            }
        }, name); // Pass the name to fetchData as an additional parameter
    }

    // Function to handle saving changes from the modal
    async function saveModalChanges() {
        const name = $('#stanza-name').val();  // Retrieve the hidden stanza name
        const ticketType = $('#ticket-type').val();
        const sourceType = $('#source-type').val();
        const interval = $('#interval').val();
        const index = $('#index').val();

        // Construct the updateData object with all fields to be updated
        const updateData = {
            "name": name,
            "atr_ticket_type": ticketType,
            "sourcetype": sourceType,
            "interval": interval,
            "index": index
        };

        // Add createStanza key only if the modal is for a new stanza
        if (isNewStanza) {
            updateData.createStanza = true;
            updateData.disabled = "1"; // By default, new stanzas are disabled
        }

        // Use saveData to update the modal fields
        const success = await saveData(updateData);

        if (success) {
            alert(isNewStanza ? "New stanza created successfully!" : "Data updated successfully!");
            $('#modalconfig').hide();  // Close the modal
            fetchData(["Name", "atr_ticket_type", "index", "sourcetype", "status"], populateTable, "all");  // Refresh the table
        }
    }

    // Event listener for toggle switch change
    $(document).off('change', '.status-toggle').on('change', '.status-toggle', async function() {
        const toggle = $(this);  // Get the toggle element as jQuery object
        const name = $(this).data("name");  // Get the stanza name from data attribute
        const newStatus = this.checked ? "0" : "1";  // If checked, set disabled to 0, else 1

        console.log("Toggle change triggered...");
        toggle.prop("disabled", true);  // Temporarily disable the toggle to prevent multiple clicks

        // Use saveData to update only the disabled status
        const success = await saveData({ name: name, disabled: newStatus });

        if (!success) {
            // Revert the toggle in case of failure
            toggle.prop("checked", !this.checked);
            // Update script running status.
            setTimeout(fetchRunningStatus, 1000);
        }

        // Re-enable the toggle after 500 milliseconds
        setTimeout(() => toggle.prop("disabled", false), 500);

        // Update script running status.
        setTimeout(fetchRunningStatus, 1000);
    });


    // Event listener for clicking on a name link to open the modal
    $(document).on('click', '.name-link', function(event) {
        event.preventDefault();
        const name = $(this).data('name');
        console.log("Asking modal infor for the table name-", name);
        showModal(name);  // Open modal and populate with the clicked stanza's data
    });

    // Event listener for close button in the modal
    $(document).on('click', '.modal-close-button', function() {
        $('#modalconfig').hide();  // Close the modal
    });

    // Event listener for save button in the modal
    $('#save-modal').on('click', saveModalChanges);

    $(document).ready(async function() {
        console.log("Getting ATR Table Details...");
        // Initial data fetch
        // Get data for all the tables saved and populate the table on UI.
        fetchData(["Name", "atr_ticket_type", "index", "sourcetype", "status"], populateTable, "all");

        fetchRunningStatus();
    });

    async function fetchRunningStatus() {
        const url = Splunk.util.make_url("/custom/" + appName + "/table_controller/get_running_status");

        try {
            const response = await TaSecurityUtils.getRequestWithSecurity(url, {});


            if (response.status === "Success") {
                // Set status circle to green
                $("#status-circle").removeClass("grey").addClass("green");

                // Set status message
                $("#status-message").text(response.message);
            } else if (response.status === "Failed") {
                // Set status circle to grey
                $("#status-circle").removeClass("green").addClass("grey");

                // Set status message
                $("#status-message").text(response.message);
            }
        } catch (error) {
            // Handle request errors
            console.error("Error fetching running status");
            $("#status-circle").removeClass("green").addClass("grey");
            $("#status-message").text("Error checking process status.");
        }
    }

});