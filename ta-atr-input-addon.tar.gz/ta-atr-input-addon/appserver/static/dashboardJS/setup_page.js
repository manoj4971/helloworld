// Dynamically fetch the app name from the current URL
// get app name from url
var url = window.location.href.split("/");
let appName = url[url.indexOf("app") + 1];
let default_app = 'ta-atr-input-addon';
appName != default_app ? console.log("AppName:" + appName + " Default:" + default_app) : console.log("appname and defautl are same.");

require.config({
    paths: {
        'tasecurityUtils': '../../app/' + appName + '/js/ta_securityUtils',
        'Encrypter': '../../app/' + appName + '/js/crypto-js.min',
    },
    scriptType: "module"
});


require([
    "tasecurityUtils",
    "Encrypter",
], function(TaSecurityUtils,Encrypter) {
    // Log SecurityUtils to check if it's correctly loaded
    console.log("SecurityUtils loaded:", TaSecurityUtils);
    console.log("Encrypter loaded:", Encrypter);

    // General function to generate a random key or IV of specified byte size
    function generateRandomKey(size) {
        return Encrypter.lib.WordArray.random(size); // size in bytes (e.g., 32 for AES-256 key, 16 for 128-bit IV)
    }

    // Function to get the global key back from Base64
    function getDecodedKey(base64Key) {
        return Encrypter.enc.Base64.parse(base64Key); // Decode the Base64 key to WordArray
    }

    const globalKey  = generateRandomKey(32);  // Generate a random encryption key
    const globalKeyBase64 = Encrypter.enc.Base64.stringify(globalKey); // Encode the key in Base64 for easy transmission

    // AES Encryption function with a unique IV for each encryption
    function aesEncrypt(plaintext) {
        // Generate a unique random IV for this encryption
        const iv = generateRandomKey(16); // 128-bit IV

        // Decode the global key back to WordArray for use in encryption
        const key = getDecodedKey(globalKeyBase64);

        // Encrypt the plaintext using the global key and the unique IV
        const encrypted = Encrypter.AES.encrypt(plaintext, key, {
            iv: iv,
            mode: Encrypter.mode.CBC,
            padding: Encrypter.pad.Pkcs7
        });

        // Concatenate IV and ciphertext, encode in Base64
        const encryptedWithIv = iv.concat(encrypted.ciphertext);
        const returnValue = Encrypter.enc.Base64.stringify(encryptedWithIv);

        console.log("global key:", globalKey);
        console.log("Decoded key:", key);
        console.log("key b64 key:", globalKeyBase64);
        console.log("iv:", iv);
        console.log("encrypted:", encrypted);
        console.log("encrypted with iv:", encryptedWithIv);
        console.log("return Value:", returnValue);

        return returnValue;
    }

    // Function to populate form fields with existing configuration data
    function populateFields(configData) {
        document.getElementById('username').value = configData.Username || '';
        document.getElementById('password').value = '';  // Leave empty for security
        document.getElementById('url').value = configData.URL || '';
        document.getElementById('sortBy').value = configData.sortBy || '';
        document.getElementById('sortDirection').value = configData.sortDirection || '';
        document.getElementById('recordCount').value = configData.recordCount || '';
        document.getElementById('startDate').value = configData.startDate || '';
        document.getElementById('splunk_username').value = configData.splunk_username || '';
        document.getElementById('splunk_password').value = '';  // Leave empty for security
    }

    // Fetch current configuration on page load
    $(document).ready(async function() {
        const settings_url = Splunk.util.make_url("/custom/" + appName + "/config_controller/check_validation_status");
        try {
            const response = await TaSecurityUtils.getRequestWithSecurity(settings_url);
            if (response.status === "Success" && response.data) {
                populateFields(response.data);
            } else {
                console.warn("Configuration data not found or incomplete.");
            }
        } catch (error) {
            console.error("Error fetching configuration:", error);
        }
    });

    // Directly handle the click event on the "Save Settings" button
    // Handle Save button click to save configuration
    $(document).on('click', '.submit-button', async function() {
        try {
            if (!validateInputs())
            {
                return;
            }
            const username = document.getElementById('username').value;
            let password = aesEncrypt(document.getElementById('password').value);
            const url = document.getElementById('url').value;
            const sortBy = document.getElementById('sortBy').value;
            const sortDirection = document.getElementById('sortDirection').value;
            const recordCount = document.getElementById('recordCount').value;
            const startDate = document.getElementById('startDate').value;
            const splunk_username = document.getElementById('splunk_username').value;
            let splunk_password = aesEncrypt(document.getElementById('splunk_password').value);

            const configData = {
                "Username": username,
                "Password": password,
                "URL": url,
                "sortBy": sortBy,
                "sortDirection": sortDirection,
                "recordCount": recordCount,
                "startDate": startDate,
                "splunk_username": splunk_username,
                "splunk_password": splunk_password,
                "key": globalKeyBase64
            };

            console.log("Config Data is : ", configData);

            const save_url = Splunk.util.make_url("/custom/" + appName +"/config_controller/my_function");
            try {
                await TaSecurityUtils.postRequestWithSecurity(save_url, configData);
                alert("Configuration saved successfully! Redirecting...");
                console.log("Configuration saved successfully");

                // Redirect to Data Inputs page after saving
                const baseUrl = window.location.origin;
                setTimeout(() => {
                    window.location.href = "table_view";
                }, 1000);
            } catch (error) {
                alert("Save Failed, Check logs.");
                console.error("Save failed:", error);
            }
        } catch (e) {
            console.error("Error handling the form submission:", e);
        }
    });

    function validateInputs() {
    // Map of field names to their corresponding DOM elements
    const fields = {
        "Username": document.getElementById('username').value.trim(),
        "Password": document.getElementById('password').value.trim(),
        "URL": document.getElementById('url').value.trim(),
        "Sort By": document.getElementById('sortBy').value.trim(),
        "Sort Direction": document.getElementById('sortDirection').value.trim(),
        "Record Count": document.getElementById('recordCount').value.trim(),
        "Start Date": document.getElementById('startDate').value.trim(),
        "Splunk Username": document.getElementById('splunk_username').value.trim(),
        "Splunk Password": document.getElementById('splunk_password').value.trim()
    };

    // Array to collect the names of empty fields
    const emptyFields = [];

    // Iterate over the fields to check for empty values
    for (const [fieldName, fieldValue] of Object.entries(fields)) {
        if (!fieldValue) {
            emptyFields.push(fieldName); // Add empty field name to the array
        }
    }

    // If there are empty fields, raise an alert and return false
    if (emptyFields.length > 0) {
        const alertMessage = `The following fields are empty and must be filled:\n\n${emptyFields.join(', ')}`;
        alert(alertMessage);
        return false; // Validation failed
    }

    return true; // Validation passed
}



});