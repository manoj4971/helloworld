import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib.decorators import expose_page
from splunk.appserver.mrsparkle.lib.util import make_splunkhome_path
import six.moves.configparser
import os
import sys
import json
import subprocess
import traceback
import logging
import time

APP_NAME = "ta-atr-input-addon"

# Set up logging for table_controller (mimics custom_log behavior)
def setup_controller_logging():
    """Set up logging scoped to this app to prevent Splunk internal log leakage"""
    log_directory = make_splunkhome_path(['etc', 'apps', APP_NAME, 'bin', 'logs'])

    # Create logs directory if it doesn't exist
    if not os.path.exists(log_directory):
        try:
            os.makedirs(log_directory)
        except Exception:
            pass  # If we can't create it, logging will handle the error

    log_file = os.path.join(log_directory, 'table_controller.log')

    # Use a named logger scoped to this app — never touch the root logger
    app_logger = logging.getLogger(APP_NAME)
    app_logger.setLevel(logging.DEBUG)
    app_logger.propagate = False  # Prevent Splunk's root handlers from receiving our records
    app_logger.handlers = []     # Clear any handlers if this runs more than once

    # File handler
    try:
        f_handler = logging.FileHandler(log_file)
        f_handler.setLevel(logging.DEBUG)
        f_handler.setFormatter(logging.Formatter(
            '%(asctime)s  %(levelname)-8s %(module)s/#%(lineno)d - %(message)s'
        ))
        app_logger.addHandler(f_handler)
    except Exception as e:
        print(f"Warning: Could not set up file logging: {e}")

    # Stream handler (stdout)
    s_handler = logging.StreamHandler(sys.stdout)
    s_handler.setLevel(logging.DEBUG)
    s_handler.setFormatter(logging.Formatter(
        '%(asctime)s  %(levelname)-8s,%(module)s,#%(lineno)d,%(message)s'
    ))
    app_logger.addHandler(s_handler)

# Initialize logging
setup_controller_logging()
logger = logging.getLogger(APP_NAME)
logging.Formatter.converter = time.gmtime
logger.info("Table Controller initialized.")



class Controller(controllers.BaseController):
    appName = APP_NAME
    PID_FOLDER = make_splunkhome_path(['etc', 'apps', appName, 'bin', 'pidLock'])
    PID_FILE = os.path.join(PID_FOLDER, 'dataPull_master.pid')

    @expose_page(must_login=False)
    def get_inputs_data(self, **kwargs):
        logger.info("get_inputs_data endpoint called with parameters: %s", kwargs)

        # Path to the configuration file
        settings_conf = make_splunkhome_path(['etc', 'apps', self.appName, 'default', 'inputs.conf'])
        logger.debug("Configuration file path: %s", settings_conf)

        # Check if the configuration file exists
        if not os.path.exists(settings_conf):
            logger.error("Configuration file not found at: %s", settings_conf)
            return self.render_json({"status": "Failed", "message": "Configuration file not found."})

        # Load configuration to retrieve data
        settings = six.moves.configparser.ConfigParser()
        settings.read(settings_conf)

        # Retrieve optional fields parameter if provided
        requested_fields = kwargs.get('fields', '').split(',')  # Get fields as a comma-separated string
        bring_table = kwargs.get('bringTable', 'all')  # Get bringTable parameter
        logger.debug("Requested fields: %s, bringTable: %s", requested_fields, bring_table)

        # List to store stanza data
        data = []

        try:
            logger.debug("Reading configuration file and processing stanzas")
            # Process each section (stanza) in the inputs.conf
            for section in settings.sections():
                if section.startswith("mywizard360-atr-modular-input://"):
                    # Extract the "Name" from the stanza (e.g., "STANDALONE" in the example)
                    name = section.split("://")[-1]
                    logger.debug("Processing stanza: %s", name)

                    # If bringTable is set to a specific table name, skip other stanzas
                    if bring_table != 'all' and name != bring_table:
                        logger.debug("Skipping stanza %s (not matching bringTable filter)", name)
                        continue

                    # Define all available fields for each stanza
                    stanza_data = {
                        "Name": name,
                        "atr_ticket_type": settings.get(section, 'atr_ticket_type', fallback=''),
                        "index": settings.get(section, 'index', fallback=''),
                        "sourcetype": settings.get(section, 'sourcetype', fallback=''),
                        "interval": settings.get(section, 'interval', fallback=''),
                        "status": "Disabled" if settings.get(section, 'disabled', fallback='1') == '1' else "Enabled"
                    }

                    # Filter fields if requested
                    if requested_fields and requested_fields != ['']:
                        stanza_data = {k: v for k, v in stanza_data.items() if k in requested_fields}

                    # Append this stanza data to the list
                    data.append(stanza_data)
                    logger.debug("Added stanza %s to data list", name)

            # Return the filtered or full data as JSON - data is an array.
            logger.info("Successfully retrieved data for %d stanzas", len(data))
            return self.render_json({"status": "Success", "data": data})
        except Exception as e:
            logger.error("Error retrieving data: %s, Traceback: %s", str(e), traceback.format_exc())
            return self.render_json({"status": "Failed", "message": "Error retrieving data."})

    @expose_page(must_login=False, methods=['POST'])
    def update_stanza_data(self, **kwargs):
        logger.info("update_stanza_data endpoint called with parameters: %s", kwargs)
        try:
            # Path to the configuration file
            settings_conf = make_splunkhome_path(['etc', 'apps', self.appName, 'default', 'inputs.conf'])
            logger.debug("Configuration file path: %s", settings_conf)
            settings = six.moves.configparser.ConfigParser()
            settings.read(settings_conf)

            name = kwargs.get('name')
            create_stanza = kwargs.get('createStanza', False)  # Check if creating a new stanza
            logger.debug("Stanza name: %s, createStanza: %s", name, create_stanza)

            if not name:
                logger.error("No stanza name provided in request")
                return self.render_json({"status": "Failed", "message": "No stanza name provided."})

            # Define the possible fields that can be updated
            updatable_fields = ['disabled', 'atr_ticket_type', 'index', 'sourcetype', 'interval']

            # Extract and filter fields to update based on `kwargs`
            fields_to_update = {key: kwargs[key] for key in updatable_fields if key in kwargs}
            logger.debug("Fields to update: %s", fields_to_update)

            # Find the correct stanza
            stanza = f"mywizard360-atr-modular-input://{name}"

            if create_stanza:
                logger.info("Creating new stanza: %s", name)
                # Check if the stanza already exists
                if settings.has_section(stanza):
                    logger.warning("Stanza %s already exists, cannot create", name)
                    return self.render_json({"status": "Failed", "message": f"Stanza {name} already exists."})

                # Add a new stanza
                settings.add_section(stanza)
                for key, value in fields_to_update.items():
                    settings.set(stanza, key, value)
                    logger.debug("Set %s = %s for new stanza %s", key, value, name)

                # Save changes
                with open(settings_conf, "w") as config_file:
                    settings.write(config_file)
                logger.info("Successfully created stanza: %s", name)

                return self.render_json({"status": "Success", "message": f"Stanza {name} created successfully."})
            else:
                if settings.has_section(stanza):
                    logger.info("Updating existing stanza: %s", name)
                    # Update each field provided in the request
                    for key, value in fields_to_update.items():
                        settings.set(stanza, key, value)
                        logger.debug("Updated %s = %s for stanza %s", key, value, name)

                        # Check for `disabled` set to "0" and trigger script
                        if key == "disabled" and value == "0":
                            logger.info("Stanza %s enabled, launching dataPull_master script", name)
                            # Define the path to the script you want to run
                            script_path = make_splunkhome_path(['etc', 'apps', self.appName, 'bin', 'dataPull_master.py'])
                            args = ["/opt/splunk/bin/splunk", "cmd", "python", script_path]
                            logger.debug("Subprocess command: %s", ' '.join(args))

                            try:
                                # Run the script as a subprocess
                                process = subprocess.Popen(args)
                                logger.info("Successfully launched dataPull_master script with PID: %s", process.pid)
                            except Exception as e:
                                logger.error("Script launch failed. Exception: %s, Traceback: %s", e, traceback.format_exc())
                                return self.render_json({"status": "Failed", "message": f"Script launch failed. exception: {e}, Traceback:{traceback.format_exc()}"})


                    # Save changes back to inputs.conf
                    with open(settings_conf, "w") as config_file:
                        settings.write(config_file)
                    logger.info("Successfully updated stanza: %s", name)

                    return self.render_json({"status": "Success", "message": f"Data updated for {name}"})
                else:
                    logger.error("Stanza %s not found for update", name)
                    return self.render_json({"status": "Failed", "message": f"Stanza {name} not found."})
        except Exception as e:
            logger.error("Error in update_stanza_data: %s, Traceback: %s", str(e), traceback.format_exc())
            return self.render_json({"status": "Failed", "message": str(e)})

    @expose_page(must_login=False)
    def get_running_status(self, **kwargs):
        """
        API endpoint to check if the data pull process is running.
        """
        logger.info("get_running_status endpoint called")
        try:
            logger.debug("Checking PID file at: %s", self.PID_FILE)
            # Check if the PID file exists
            if os.path.exists(self.PID_FILE):
                try:
                    with open(self.PID_FILE, 'r') as f:
                        pid = int(f.read().strip())
                    logger.debug("Found PID file with PID: %s", pid)

                    # Check if the process with this PID is running
                    os.kill(pid, 0)  # Signal 0 checks process existence without killing
                    logger.info("Data pull process is online with PID: %s", pid)
                    return self.render_json({
                        "status": "Success",
                        "message": "The data pull process is online.",
                        "data": True
                    })
                except ProcessLookupError:
                    # Process with the given PID does not exist
                    logger.warning("PID file exists but process %s is not running", pid)
                    return self.render_json({
                        "status": "Failed",
                        "message": "The process is offline.",
                        "data": False
                    })
                except Exception as e:
                    logger.error("Error while fetching status: %s, Traceback: %s", str(e), traceback.format_exc())
                    return self.render_json({
                        "status": "Failed",
                        "message": f"Error while fetching status.",
                        "data": False
                    })
            else:
                # If the PID file doesn't exist, the process is not running
                logger.info("PID file does not exist, process is offline")
                return self.render_json({
                    "status": "Failed",
                    "message": "The process is offline.",
                    "data": False
                })
        except Exception as e:
            # Handle unexpected errors
            logger.error("Unexpected error in get_running_status: %s, Traceback: %s", str(e), traceback.format_exc())
            return self.render_json({
                "status": "Failed",
                "message": f"Unexpected error occurred.",
                "data": False
            })


