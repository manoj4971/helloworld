import splunk.appserver.mrsparkle.controllers as controllers
from splunk.appserver.mrsparkle.lib.decorators import expose_page
from splunk.appserver.mrsparkle.lib.util import make_splunkhome_path
import six.moves.configparser
import os


class Controller(controllers.BaseController):
    appName = 'ta-atr-input-addon'

    @expose_page(must_login=False)
    def my_function(self, **kwargs):
        # Path to the configuration file
        settings_conf = make_splunkhome_path(['etc', 'apps', self.appName, 'default', 'mywizard360-atr-modular-input.conf'])
        settings = six.moves.configparser.ConfigParser()
        settings.optionxform = str  # Preserve the original case of keys
        read_files = settings.read(settings_conf)

        if not read_files:
            return self.render_json({"status": "Failed", "message": "Configuration file could not be read: {}".format(settings_conf)})

        # Ensure 'config' section exists
        if not settings.has_section('config'):
            settings.add_section('config')

        # Update configuration based on provided values
        for key in ['Username', 'Password', 'URL', 'sortBy', 'sortDirection', 'recordCount', 'startDate', 'splunk_username', 'splunk_password', 'key']:
            if key in kwargs:
                settings.set('config', key, kwargs[key])

        # Save updated configuration back to the file
        with open(settings_conf, "w") as config_file_local:
            settings.write(config_file_local)

        return self.render_json({"status": "Success", "message": "Configuration saved successfully"})

    @expose_page(must_login=False)  # Expose this page to check if 'enable_validation' is set
    def check_validation_status(self, **kwargs):
        # Path to the configuration file
        settings_conf = make_splunkhome_path(['etc', 'apps', self.appName, 'default', 'mywizard360-atr-modular-input.conf'])

        # Check if the configuration file exists
        if not os.path.exists(settings_conf):
            return self.render_json({"status": "Failed", "message": "Configuration file not found."})

        # Load configuration to retrieve data
        settings = six.moves.configparser.ConfigParser()
        settings.read(settings_conf)

        # Gather fields for the UI
        if settings.has_section('config'):
            config_data = {key: settings.get('config', key, fallback='') for key in [
                'Username', 'Password', 'URL', 'sortBy', 'sortDirection', 'recordCount', 'startDate', 'splunk_username', 'splunk_password'
            ]}
            return self.render_json({"status": "Success", "data": config_data})
        else:
            return self.render_json({"status": "Failed", "message": "Configuration section not found."})

